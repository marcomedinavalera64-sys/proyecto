# Quesería Los Alpes

Prototipo académico de pedidos e inventario en Python 3.12 o superior. No necesita paquetes externos. Trabaja con una sola instancia local.

## Ejecución

Desde esta carpeta:

```
python main.py
python -m unittest -v
```

El catálogo inicial es de demostración, tomado de los ejemplos del informe original: fresco 20 kg a S/ 18; mantecoso 15 kg a S/ 22; suizo 12 kg a S/ 28; mantequilla 25 kg a S/ 25. No representa existencias ni precios vigentes de la empresa. Los pedidos aceptados se guardan en `datos/queseria.json` al confirmarlos. Reiniciar conserva datos. La constancia es interna y no es comprobante tributario.

No elimine el archivo de datos para reiniciar una operación real. Trabaje con una copia del proyecto para demostraciones. Haga respaldos cuando la aplicación esté cerrada. Ante un JSON dañado, el programa no lo reemplaza automáticamente.

## Archivos

- negocio.py: validación, registro, búsqueda lineal, ordenamiento por inserción y resumen diario.
- archivos.py: lectura, validación y reemplazo del JSON mediante archivo temporal.
- main.py: menú de consola y manejo de errores.
- test_prototipo.py: 18 pruebas automatizadas con carpetas temporales.

## Alcance

No incluye edición de precios, reposición, anulaciones, autenticación, facturación electrónica ni operación concurrente. Se almacena un nombre y el detalle de compra; no se necesita DNI ni teléfono. No publique datos reales en GitHub.

## Control de versiones pendiente del grupo

Los nombres, aportes, enlace remoto y capturas de GitHub deben corresponder al trabajo real de los integrantes. Este paquete no atribuye commits a estudiantes ni reconstruye una historia pasada. Para continuar, creen su repositorio, configuren su identidad real y registren cambios auténticos. Usen ramas para tareas distintas, revisen diferencias y hagan commits descriptivos. Ejemplo de consulta del historial: `git log --oneline --graph --all`.

## Uso de IA

El código y su documentación se elaboraron con asistencia de IA en esta preparación. El equipo debe revisarlos, ejecutar las pruebas y explicar su funcionamiento. Adjunte la declaración oficial del aula virtual y describa el alcance real del apoyo recibido.
