"""Reglas del prototipo Los Alpes. Datos de demostración, no inventario real."""
from copy import deepcopy
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
import re


def numero(texto, cero=False):
    texto = str(texto).strip().replace(',', '.')
    if not re.fullmatch(r'[0-9]{1,6}(\.[0-9]{1,3})?', texto):
        raise ValueError('Use un número positivo con hasta tres decimales.')
    valor = Decimal(texto)
    if valor < 0 or (valor == 0 and not cero):
        raise ValueError('La cantidad debe ser mayor que cero.')
    return valor


def inicial():
    nombres = ['Queso fresco', 'Queso mantecoso', 'Queso suizo', 'Mantequilla']
    precios = ['18', '22', '28', '25']
    stocks = ['20', '15', '12', '25']
    # Arreglos paralelos usados para construir el catálogo inicial.
    productos = [{'id': i+1, 'nombre': nombres[i], 'precio': precios[i],
                  'stock': stocks[i]} for i in range(len(nombres))]
    return {'productos': productos, 'pedidos': []}


def buscar(pedidos, codigo):
    codigo = codigo.strip().upper()
    for pedido in pedidos:
        if pedido['codigo'] == codigo:
            return pedido
    return None


def ordenar(pedidos):
    # Inserción: desplaza elementos hasta encontrar la posición del código.
    copia = list(pedidos)
    for i in range(1, len(copia)):
        actual = copia[i]
        j = i - 1
        while j >= 0 and copia[j]['codigo'] > actual['codigo']:
            copia[j+1] = copia[j]
            j -= 1
        copia[j+1] = actual
    return copia


def registrar(estado, cliente, canal, lineas, guardar):
    cliente = ' '.join(cliente.split())
    if not 2 <= len(cliente) <= 80 or not all(c.isalpha() or c in " '-" for c in cliente):
        raise ValueError('Nombre inválido: use entre 2 y 80 caracteres de nombre.')
    canal = canal.strip().casefold()
    if canal not in ('presencial', 'telefónico'):
        raise ValueError('Canal inválido.')
    if not lineas:
        raise ValueError('El pedido está vacío.')
    nuevo = deepcopy(estado)
    cantidades = {}
    for identificador, cantidad in lineas:
        if type(identificador) is not int:
            raise ValueError('Producto inválido.')
        cantidades[identificador] = cantidades.get(identificador, Decimal('0')) + numero(cantidad)
    detalle, total = [], Decimal('0')
    for identificador, cantidad in cantidades.items():
        producto = next((p for p in nuevo['productos'] if p['id'] == identificador), None)
        if producto is None:
            raise ValueError('Producto inexistente.')
        stock = numero(producto['stock'], cero=True)
        if cantidad > stock:
            raise ValueError('Stock insuficiente para ' + producto['nombre'])
        subtotal = (cantidad * numero(producto['precio'])).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)
        producto['stock'] = str(stock - cantidad)
        detalle.append({'producto': identificador, 'nombre': producto['nombre'],
                        'kg': str(cantidad), 'precio': producto['precio'], 'subtotal': str(subtotal)})
        total += subtotal
    siguiente = max((int(p['codigo'][4:]) for p in estado['pedidos']), default=0) + 1
    if siguiente > 999999:
        raise ValueError('Se alcanzó el límite de códigos del prototipo.')
    pedido = {'codigo': f'PED-{siguiente:06d}', 'fecha': datetime.now().astimezone().isoformat(timespec='seconds'),
              'cliente': cliente, 'canal': canal, 'detalle': detalle, 'total': str(total)}
    nuevo['pedidos'].append(pedido)
    guardar(nuevo)  # Solo se confirma después de guardar correctamente.
    estado.clear()
    estado.update(nuevo)
    return pedido


def resumen(estado, dia):
    pedidos = [p for p in estado['pedidos'] if p['fecha'][:10] == dia]
    return len(pedidos), sum((Decimal(p['total']) for p in pedidos), Decimal('0'))
